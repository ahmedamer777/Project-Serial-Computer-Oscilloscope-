﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.IO;


namespace Project_Osciloscope
{
    public partial class Form1 : Form
    {
        Graphics g;
        //int fonty;
        //SolidBrush b = new SolidBrush(Color.Black);
        //SolidBrush br = new SolidBrush(Color.Red);
        Pen pen = new Pen(Color.Black, 1);
        Pen penr = new Pen(Color.Red, 1);
        Pen penbl = new Pen(Color.Blue, 1);
        char en = '1';
        static int xx = 800;                                   //generic size
        static int yy = 258;
        char but = '1';
        int? prevx=null;
        int? prevy=null;
        string RX;
        //int[] med = new int[10] ;
        //int[] com = new int[10];
        char plotit = '0';
        int i = 0;
        //int value = 1;
        //double temp;
        //float con;
        int plotval;
        char[] toto = new char[4];
        byte[] conv = new byte[4];
        int x = 0;
        int samples = 0;
        int avg = 0;
        double mvalu;
        double curvall;

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
           
        }              
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        void clear()
        {
            try
            {
                g.DrawLine(pen, new Point(0, yy / 2), new Point(xx, yy / 2));

                g.DrawLine(pen, new Point(100, 0), new Point(100, yy));
                
                g.DrawLine(pen, new Point(200, 0), new Point(200, yy));
               
                g.DrawLine(pen, new Point(300, 0), new Point(300, yy));
               
                g.DrawLine(pen, new Point(400, 0), new Point(400, yy));

                g.DrawLine(pen, new Point(500, 0), new Point(500, yy));

                g.DrawLine(pen, new Point(600, 0), new Point(600, yy));

                g.DrawLine(pen, new Point(700, 0), new Point(700, yy));
      
            }
            catch { }
        }
        
        private void button1_Click(object sender, EventArgs e)      //connect button
        {
            
            if (en == '1')
            {

                    button3.Enabled = true;
                    samples = 0;
                    timer2.Start();
                    prevx = null;
                    g.Clear(Color.White);
                    x = 0;
                    clear();
                    en = '0';
                    serialPort1.PortName = name_box.Text;
                    serialPort1.BaudRate = Convert.ToInt32(baud_box.Text);
                    serialPort1.DataBits = Convert.ToInt32(bits_box.Text);
                    serialPort1.Open();
                    button1.Enabled = false;
                    button2.Enabled = true;

            }
            else MessageBox.Show("COM Port is still Open Or in Use "); 
        }
        
        private void button2_Click(object sender, EventArgs e)      //disconnect button
        {
            button3.Enabled = false;            
            en = '1';            
            button1.Enabled = true;
            button2.Enabled = false;
            timer2.Stop();
            samples = 0;
            but = '1';
        }      
      
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                RX = serialPort1.ReadExisting();
                this.Invoke(new EventHandler(disp));
            }
            catch (System.TimeoutException) { }
            finally
            {
                if (en == '1') { serialPort1.Close(); }
            }
        }        
       
        private void disp(object s, EventArgs e)
        {
            input.Text = RX;

            try
            {
                conv = Encoding.ASCII.GetBytes(RX);
            }
            catch { }
            try
            {
                toto[0] = Convert.ToChar(conv[0]);
                toto[1] = Convert.ToChar(conv[1]);
                toto[2] = Convert.ToChar(conv[2]);
                toto[3] = Convert.ToChar(conv[3]);
                filter.Text = toto[0].ToString() + toto[1].ToString() + toto[2].ToString() + toto[3].ToString();
                plotval = Convert.ToInt32(toto[0].ToString() + toto[1].ToString() + toto[2].ToString() + toto[3].ToString());
                filter.Text = Convert.ToString(plotval.ToString());
                if (plotval != 0) { plotval /= 4; }
                               
                //plotval = conv[0];
                //timer1.Start();
            }
            catch { }          

            if (Convert.ToInt32(x) > xx)
            {
                x = 0;
                prevx = null;
                g.Clear(Color.White);
                clear();
            }
            textBox1.Text = plotval.ToString();
            plotval = 255 - plotval;            
            //med[i] = plotval;
            //com[i] = med[i];
            //value *= med[i];
            avg += plotval; //med[i];
            i++;
            
            if (i == 20)
            {
                i = 0;
                plotit = '1';
                ////try
                ////{
                //    for (int j = 0; j < 10; j++)
                //    {
                //        for (int k = 0; k < 10; k++)                      //median filter test
                //        {
                //            if (med[k] > med[j])
                //            {
                //                com[j] = med[k];
                //            }
                //        }
                //    }
                //    //temp = System.Math.Pow(value,0.2); 
                avg /= 20;
                plotval = avg;
                avg = 0;           
                
                //}
                //catch { }
                //value = 1;
                x+=2;
                curvall = ((255-plotval) * 19.531);
                curval.Text = curvall.ToString("#0,000.00");
            }
            
            try
            {
                if (plotit == '1')
                {
                    plotit = '0';                    
                    //g.FillEllipse(br,x,plotval, Convert.ToInt32(fonty), Convert.ToInt32(fonty));
                    g.DrawLine(penr, new Point(prevx ?? x, prevy ?? plotval), new Point(x, plotval));
                    prevx = x;
                    prevy = plotval;
                }
            }
            catch { }
            samples++;
            

        }          

        private void button4_Click(object sender, EventArgs e)
        {
            g.Clear(Color.White);
            clear();
            prevx = null;            
            x = 0;
            timer2.Stop();
            samples = 0;
            timer2.Start();
            textBox2.Text = "";
            mval.Text = "";
            interv.Text = "";


        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            textBox2.Text = samples.ToString();
            timer2.Start();
            samples = 0;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (button1.Enabled == false)
            {
                en = '1';               
                MessageBox.Show("plz close the serial connection next time" ,"Warning !");
                
            }
            
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            if (but == '1')
            {
                but = '0';
                en = '1';                
                timer2.Stop();
                samples = 0;
            }
            else
            {
                if (en == '1')
                {
                    but = '1';
                    samples = 0;
                    timer2.Start();                   
                    clear();
                    en = '0';
                    serialPort1.PortName = name_box.Text;
                    serialPort1.BaudRate = Convert.ToInt32(baud_box.Text);
                    serialPort1.DataBits = Convert.ToInt32(bits_box.Text);
                    serialPort1.Open();
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            clear();
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            mvalu = ((255 - e.Y) * 19.531);
            mval.Text = mvalu.ToString("#0,000.00");
        }
        int bx;
        int by;
        char bb = '0';
        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (bb == '0')
            {
                bx = e.X;
                by = e.Y;
                bb = '1';
            }
            else if (bb == '1')
            {
                g.DrawLine(penbl, new Point(e.X, e.Y), new Point(bx, by));
                bb = '0';
                interv.Text = Convert.ToString(System.Math.Abs(bx-e.X)*0.005);
            }
            
        }        

    }
}
